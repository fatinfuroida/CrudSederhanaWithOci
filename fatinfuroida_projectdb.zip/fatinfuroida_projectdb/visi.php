<!DOCTYPE html>
<html lang="en">
<head>
  <title>Daftar Buku TA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="css/bootstrap.min.css"type="text/css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    
<style>
    #table table-condensed{
        background: #1E90FF;
    }
</style>
    
<div class="container">
  <br>
  <h2 align="center">Visi Misi Perpustakaan Politeknik Elektronika Negeri Surabaya</h2>

  <br>
  <table class="table table-condensed1">
    <thead>
      <tr>
        <th><h2 align="center">VISI</h2></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><p align="justify">Sesuai dengan visi dan misi PENS, Perpustakaan memiliki visi yakni: menjadi perpustakaan yang unggul dengan fasilitas yang lengkap, modern dan mampu memberikan pelayanan terbaik kepada pemakainya dengan berbasis teknologi komputer.</p></td>
      </tr>
    </tbody>
  </table>
    
     <br>
  <table class="table table-condensed2">
    <thead>
      <tr>
        <th><h2 align="center">MISI</h2></th>
      </tr>
    </thead>
    <tbody>
      <tr>
       <td><p align="justify">1. Mengoleksi semua informasi yang berhubungan dengan ketentuan akademis di PENS.</p><p align="justify">2. Mengelola informasi dengan canggih dan modern agar dapat diakses pemakai dengan mudah, cepat dan tepat.</p><p align="justify">3. Memberikan fasilitas yang memadai kepada pemakai agar dapat mewujudkan fungsi perpustakaan sebagai sarana bantu proses belajar mengajar.</p></p><p align="justify">4. Memberikan fasilitas yang memadai kepada pemakai agar dapat mewujudkan fungsi perpustakaan sebagai sarana bantu proses belajar mengajar.</p></td>
      </tr>
    </tbody>
  </table>
    
    
</div>

</body>
</html>
