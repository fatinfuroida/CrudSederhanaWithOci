<!DOCTYPE html>
<html lang="en">
<head>
  <title>Daftar Buku Umum</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="css/bootstrap.min.css"type="text/css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>

<!--header -->
      <div class="container"></div>
        <div id="header">
            <img src="Untitled-2.png" width="570" height="110"/>
        </div>
      <div class="container"></div>
<!--end header -->
	
<div class="container">
  <br>
  <br>
  <h3>Daftar Buku Umum Politeknik Elektronika Negeri Suabaya</h3>
    <table class="table">
                <thead>
                  <tr class='info'>
                    <th>ID BUKU</th>
                    <th>JUDUL</th>
                    <th>PENGARANG</th>
                    <th>PENERBIT</th>
					<th>JENIS BUKU</th>
                  </tr>
                </thead>
                <tbody>
					<?php
					$conn=oci_connect('jual','jual','localhost/xe');
					
					$query="SELECT * FROM DAFTAR_BUKU WHERE JENIS_BUKU='umum'";
					$s=oci_parse($conn,$query);
					oci_execute($s,OCI_DEFAULT);
					while($res=oci_fetch_array($s,OCI_BOTH)){
					echo " <tr class='danger'>\n";
					echo " <td>".($res['ID_BUKU']) ."</td>";
					echo " <td>".($res['JUDUL']) ."</td>";
					echo " <td>".($res['PENGARANG']) ."</td>";
					echo " <td>".($res['PENERBIT']) ."</td>";
					echo " <td>".($res['JENIS_BUKU']) ."</td>";
					}
					
					?>
                </tbody>
              </table>
	
</div>
</body>
</html>

