<!DOCTYPE html>
<html lang="en">
<head>
  <title>Logout</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="css/bootstrap.min.css"type="text/css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
	


<!--header -->
      <div class="container"></div>
        <div id="header">
            <img src="Untitled-2.png" width="570" height="110"/>
        </div>
      <div class="container"></div>
<!--end header -->

	<br>
	<br>
	<br>
	<br>
	<br>
	<div class="row">
          <div class="col-md-12">
            <div class="card">
			  <center><img src="logout.png" width="60px" height="60px"></center>
              <center><h2 class="card-title">Logout Successfull</h2></center>
			  <h4 align="center">Terimakasih Sudah Mengunjungi Perpustakaan Polieknik Elektronika Negeri Surabaya</h4>
               <div class="col-md-12">
				<p align="center"><a href="index.php">Masuk lagi ??</a></p>
            </div>
          </div>
        </div>
	
	
	<br>
	<br>

</div>

</body>
</html>




