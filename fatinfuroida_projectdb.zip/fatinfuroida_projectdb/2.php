<html>
<body>
  <form action="proses1.php" method="GET">
       kelas:<input type="text" name="kelas" /> </br></td>
        <table>
        <tr>
        IP :
        <td><input type="text" name="ip1"> </td>
        <td><input type="text" name="ip2"> </td>
        <td><input type="text" name="ip3"> </td>
        </tr>
        </table>
<input type="submit" />
</form>
</body>
</html>
