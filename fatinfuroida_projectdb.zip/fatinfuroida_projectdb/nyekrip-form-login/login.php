<?php
	$conn=oci_connect("jual","jual","localhost/XE");
	if(isset($_POST['login']))
	{
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	$sql = "SELECT * FROM ANGGOTA where NAMA_ANGGOTA='$user' and TELEPON='$pass'";
	$sqlparse = oci_parse($conn, $sql);
	$retval = oci_execute($sqlparse) or die(oci_error());
	$row = oci_fetch_assoc($sqlparse);
	
		session_start();
		if($row['NAMA_ANGGOTA']==$user && $row['TELEPON']==$pass)
		{
			$_SESSION['NAMA_ANGGOTA'] = $row['NAMA_ANGGOTA'];
			$_SESSION['TELEPON'] = $row['TELEPON'];
	?>
			<script language="javascript">
					<!--
			location.href='admin';
			//--> 
			</script>
	<?php
		}else{
	?>
	 <script language="javascript">
			<!--
			window.alert('Login Gagal!\nCek kembali Username dan Password anda!');
			location.href='login.php';
			//--> 
			</script>
	<?php
		}
	}else{
	?>
<?php } ?>