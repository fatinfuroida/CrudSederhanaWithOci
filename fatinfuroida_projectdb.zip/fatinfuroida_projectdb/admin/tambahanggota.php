<html>
<body>
<?php
$conn=oci_connect("jual","jual","localhost/XE");
$id = $_POST['id'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$tlp = $_POST['tlp'];
$ket = $_POST['ket'];
$glr = $_POST['glr'];
$statement=oci_parse($conn, "INSERT INTO ANGGOTA (ID_ANGGOTA, NAMA_ANGGOTA, ALAMAT, TELEPON, KETERANGAN, GELAR) VALUES (:id, :nama, :alamat, :tlp, :ket, :glr)");
oci_bind_by_name($statement, ':id', $id);
oci_bind_by_name($statement, ':nama', $nama);
oci_bind_by_name($statement, ':alamat', $alamat);
oci_bind_by_name($statement, ':tlp', $tlp);
oci_bind_by_name($statement, ':ket', $ket);
oci_bind_by_name($statement, ':glr', $glr);
//oci_bind_by_name($statement, ':hd', $hd);
oci_execute($statement);
oci_commit($conn);
echo "<script>location='insertanggota.php';</script>";
?>
</body>
</html>