<!DOCTYPE html>
<html lang="en">
<head>
 <title>Daftar Staff Perpustakaan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="css/bootstrap.min.css"type="text/css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>

<style>
    #table-striped{
        width: 800;
    }
</style>

<div class="container">
  <br>
  <br>
  <h2 align="center">PIMPINAN DAN STAFF PERPUSTAKAAN PENS</h2>
   <br>
  <p>Berikut ini profil para Pimpinan Perpustakaan PENS yang senantiasa siap untuk membantu Anda:</p>
 
  <center><table class="table table-striped">
	  <?php
					$conn=oci_connect('jual','jual','localhost/xe');
					
					$query="SELECT * FROM ANGGOTA WHERE KETERANGAN='admin'";
									
								?>
    <thead>
      <tr>
        <th></th>
      </tr>
    </thead>
	  <?php
	  	$s=oci_parse($conn,$query);
					oci_execute($s,OCI_DEFAULT);
					while($res=oci_fetch_array($s,OCI_BOTH)){
	  ?>
    <tbody>
      <tr>
          <td><h4 align="center"><?php echo ($res['GELAR'])?></h4><p align="center"><?php echo ($res['NAMA_ANGGOTA'])?></p></td>
      </tr>  
    </tbody>
	  <?php
								}
							?>
  </table></center>
</div>

</body>
</html>
