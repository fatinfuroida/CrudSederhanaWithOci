<!DOCTYPE html>
<html lang="en">
<head>
  <title>Daftar Buku TA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="css/bootstrap.min.css"type="text/css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    
<style>
    #table table-condensed{
        background: #1E90FF;
    }
</style>
    
<div class="container">
  <br>
  <h2 align="center">PERSYARATAN ANGGOTA PERPUSTAKAAN PENS</h2>

     <br>
  <table class="table table-condensed1">
    <thead>
      <tr>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
       <td><h4 align="justify">A. MAHASISWA PENS / STAF PENGAJAR/ DOSEN, DAN PEGAWAI PENS</h4><br><p align="justify">1.Civitas akademika PENS otomatis menjadi anggota Perputakaan PENS.</p><p align="justify">2.Setiap kali ingin meminjam wajib membawa smartcard.</p></td>
      </tr>
    </tbody>
      
     <tbody>
      <tr>
       <td><h4 align="justify">B. DARI PERGURUAN TINGGI LAIN</h4><br><strong align="justify">Perpustakaan PENS bekerjasama dengan </strong><p align="justify">1.FKP2TN (Forum Komunikasi Perpustakaan Perguruan Tinggi Negeri) dan </p><p align="justify">2.FPPTI Jatim (Forum Komunikasi Perpustakaan Perguruan Tinggi Indonesia - Jawa Timur). </p><strong align="justify">Perpustakaan menyediakan layanan pembuatan: </strong><p align="justify">a.SURAT PENGANTAR</p><p align="justify">b.KARTU SAKTI, sebagai pengganti surat pengantar berkunjung ke perpustakaan lain yang menjadi anggota FKP2TN </p><p align="justify">c.KARTU SUPER, sebagai pengganti surat pengantar berkunjung ke perpustakaan lain yang menjadi anggota FPPTI – Jatim</p> </td>
      </tr>
    </tbody>
      
    <tbody>
      <tr>
       <td><h4 align="justify">C. Biaya dan masa berlaku:</h4><br><p align="justify">a.Surat pengantar dikenakan biaya Rp. 1.000,- / surat / mahasiswa dengan masa berlaku tergantung dari perpustakaan yang akan dikunjungi</p><p align="justify">b.KARTU SAKTI dikenakan biaya Rp. 7.500,- / kartu / mahasiswa dengan masa berlaku selama 3 bulan</p><p align="justify">c.KARTU SUPER dikenakan biaya Rp. 5.000,- / kartu / mahasiswa dengan masa berlaku selama 6 bulan</p></td>
      </tr>
    </tbody>
  </table>
    
    
</div>

</body>
</html>
